from RPA.Browser.Selenium import Selenium
#from RPA.Excel.Application import Application
from RPA.Excel.Files import Files
from RPA.FileSystem import FileSystem
import collections
import string
from RPA.PDF import PDF
from RPA.Tables import Tables
from RPA.Archive import Archive
import time
import os
import re
import glob

selenium=Selenium()
#excel_app= Application()
files= FileSystem()
pdf = PDF()
table= Tables()
arch= Archive()
excel_1= Files()


def intial_setup():
    selenium.set_selenium_timeout(15)
    selenium.set_download_directory('output')
    us_agencies_exists= files.does_file_exist('output/us_agencies.xlsx')
    if us_agencies_exists is True:
        files.remove_file('output/us_agencies.xlsx')
    print('everything ready for starting...............')


def open_the_website():
    print('opening the website')
    selenium.open_available_browser('https://itdashboard.gov/')
    selenium.maximize_browser_window()
    selenium.wait_until_page_contains_element('//a[@class="btn btn-default btn-lg-2x trend_sans_oneregular"]')
    selenium.click_element('//a[@class="btn btn-default btn-lg-2x trend_sans_oneregular"]')  
    selenium.wait_until_page_contains_element('//div[@id="agency-tiles-container"]//span[@class="h4 w200"]')


def creating_an_excel_sheet(sheetname):
    print('creating headers')
    excel_1.create_worksheet(name=sheetname)
    excel_1.set_cell_value(name=sheetname,row=1,column=1,value='Name')
    excel_1.set_cell_value(name=sheetname,row=1,column=2,value='Amount')



def scrap_the_datas(sheetname):
    print('scarping the datas from main website')
    r=2
    department_names= selenium.get_webelements('//div[@id="agency-tiles-container"]//span[@class="h4 w200"]')
    amount_spending=  selenium.get_webelements('//div[@id="agency-tiles-container"]//span[@class=" h1 w900"]')
    print('Department Name ---------- Amount spending')
    for i in range(len(department_names)):
        print(selenium.get_text(department_names[i]),'----------',selenium.get_text(amount_spending[i]))
        excel_1.set_cell_value(name=sheetname,row=r,column=1,value=selenium.get_text(department_names[i]))
        excel_1.set_cell_value(name=sheetname,row=r,column=2,value=selenium.get_text(amount_spending[i]))
        r=r+1


def add_excel_headers_investment(sheetname):
    print('putting excel headers')
    excel_1.set_cell_value(name=sheetname,row=1,column=1,value='UII')
    excel_1.set_cell_value(name=sheetname,row=1,column=2,value='Bureau')
    excel_1.set_cell_value(name=sheetname,row=1,column=3,value='Investment Title')
    excel_1.set_cell_value(name=sheetname,row=1,column=4,value='Total FY2021 Spending Reports')
    excel_1.set_cell_value(name=sheetname,row=1,column=5,value='Type')
    excel_1.set_cell_value(name=sheetname,row=1,column=6,value='CIO Rating')
    excel_1.set_cell_value(name=sheetname,row=1,column=7,value='No of Projects')


def selecting_agency_and_extracting_details():
    print('selecting agency and extarcting details')
    agency_name= os.environ.get("Department_Name")
    selenium.click_element('//div[@id="agency-tiles-container"]//span[@class="h4 w200" and text()='+chr(34)+agency_name+chr(34)+']')
    selenium.wait_until_page_contains_element('//div[@id="investments-table-container"]')
    selenium.wait_until_page_contains_element('//select[@name="investments-table-object_length"]')
    selenium.select_from_list_by_label('//select[@name="investments-table-object_length"]','All')
    selenium.wait_until_page_does_not_contain_element('//a[text()="2"]')
    extract_investments()
    print('Extraction of data completed')


def extract_investments():
    print('extract investments')
    row=2
    UII= selenium.get_webelements('//td[@class="left sorting_2"]')
    bureau= selenium.get_webelements('//div[@id="investments-table-container"]//tbody//td[2]')
    investment_title= selenium.get_webelements('//div[@id="investments-table-container"]//tbody//td[3]')
    total_spending= selenium.get_webelements('//div[@id="investments-table-container"]//tbody//td[4]')
    type_1= selenium.get_webelements('//div[@id="investments-table-container"]//tbody//td[5]')
    cio_rating = selenium.get_webelements('//div[@id="investments-table-container"]//tbody//td[6]')
    no_of_projects= selenium.get_webelements('//div[@id="investments-table-container"]//tbody//td[7]')
    count = selenium.get_element_count('//div[@id="investments-table-container"]//tbody//td[7]')
    for i in range(count):
        excel_1.set_cell_value(name='Investment',row=row,column=1,value=selenium.get_text(UII[i]))
        excel_1.set_cell_value(name='Investment',row=row,column=2,value=selenium.get_text(bureau[i]))
        excel_1.set_cell_value(name='Investment',row=row,column=3,value=selenium.get_text(investment_title[i]))
        excel_1.set_cell_value(name='Investment',row=row,column=4,value=selenium.get_text(total_spending[i]))
        excel_1.set_cell_value(name='Investment',row=row,column=5,value=selenium.get_text(type_1[i]))
        excel_1.set_cell_value(name='Investment',row=row,column=6,value=selenium.get_text(cio_rating[i]))
        excel_1.set_cell_value(name='Investment',row=row,column=7,value=selenium.get_text(no_of_projects[i]))
        row=row+1


def downloading_pdf_reports():
    print('downloading each pdf reports')
    uii_links= selenium.get_webelements('//td[@class="left sorting_2"]//a')
    uii_hrefs=[]
    
    for i in uii_links:
        link = selenium.get_element_attribute(i,"href")
        uii_hrefs.append(link)
    print('The no of pdfs to download is  {len(uii_links)}')
    for link in uii_hrefs:
        
        print('Go to '+link)
        try:
            file_name= re.findall('\d{3}\-\d+',link)[0]+'.pdf'
            print(file_name)
            selenium.go_to(link)
            selenium.wait_until_page_contains_element('//a[text()="Download Business Case PDF"]')
            selenium.click_element('//a[text()="Download Business Case PDF"]')
            file_path='output/'+file_name
            files.wait_until_created(file_path,15)
        except Exception as e:
            print(e)
            print('Some errors happenend...., so running to next reports......')
            continue


def comparing_pdfdata_with_usagencies():
    print('comparing data with us agencies')
    excel_1.open_workbook('output/us_agencies.xlsx')
    tables= excel_1.read_worksheet_as_table('Investment',header=True)
    file_list= glob.glob('output/*.pdf',recursive=True)
    print(f'pdf_data comparisions started. Total Available pdfs: {len(file_list)}')
    for file in file_list:
        data = pdf.get_text_from_pdf(file,pages=1)
        uii= re.findall('(?<=Unique Investment Identifier \(UII\):\s).*(?=Section B)',data[1])
        name_of_investment= re.findall('(?<=Name of this Investment:\s).*(?=2. Unique Investment Identifier)',data[1])
        if len(uii)==1 and len(name_of_investment)==1:
            row_uii= table.find_table_rows(tables,'UII','==',uii[0])
            row_name_of_investment= table.find_table_rows(tables,'Investment Title','==',name_of_investment[0])
            if len(row_uii)!=0 and len(row_name_of_investment)!=0:
                print(f'UII: {uii[0]}----- Name of Investment: {name_of_investment[0]}  Values matched with the excel data')
            else:
                print(f'UII: {uii[0]}----- Name of Investment: {name_of_investment[0]}  Values not matched')
        else:
            print('No values UII and name of investement from pdf  is present in excel')


try:
    intial_setup()
    open_the_website()
    excel_1.create_workbook(fmt='xlsx')
    excel_1.save_workbook('output/us_agencies.xlsx')
    excel_1.open_workbook('output/us_agencies.xlsx')
    creating_an_excel_sheet('Agencies')
    scrap_the_datas('Agencies')
    excel_1.save_workbook('output/us_agencies.xlsx')
    excel_1.create_worksheet('Investment')
    add_excel_headers_investment('Investment')
    selecting_agency_and_extracting_details()
    excel_1.save_workbook('output/us_agencies.xlsx')
    downloading_pdf_reports()
    excel_1.save_workbook('output/us_agencies.xlsx')
    selenium.close_browser()
    comparing_pdfdata_with_usagencies()
except Exception as e:
    print(e)
    selenium.close_browser()







